function clock() {
    // set the each times and grab the element of the DOM
    var hours = document.getElementById('hours');
    var minutes = document.getElementById('minutes');
    var seconds = document.getElementById('seconds');
    var ampm = document.getElementById('ampm');

    var h = new Date().getHours(); // .getHOurs method to get the local time 
    var m = new Date().getMinutes();
    var s = new Date().getSeconds();
    var am = "Am";

    if(h > 12){
        h = h - 12;
        var am = "PM";
    }
    // dispklay 0 so two digits
    h = (h < 10) ? "0" + h : h
    m = (m < 10) ? "0" + m : m
    s = (s < 10) ? "0" + s : s

    // send into the DOM that using emthod is .innerHTML so text
    hours.innerHTML = h;
    minutes.innerHTML = m;
    seconds.innerHTML = s;
    ampm.innerHTML = am;
}

var interval = setInterval(clock, 1000);