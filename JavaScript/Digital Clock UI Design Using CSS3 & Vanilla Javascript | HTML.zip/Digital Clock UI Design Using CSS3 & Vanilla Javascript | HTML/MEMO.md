[Youtube_1]
<!-- https://www.youtube.com/watch?v=CWOnjWTfPW4 -->

[@Youtube_2]
<!-- https://www.youtube.com/watch?v=fSYG0xZIc8A&t=0s -->




[-webkit-box-reflext]
<!-- https://developer.mozilla.org/en-US/docs/Web/CSS/-webkit-box-reflect -->

[.getHours]
<!-- https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date/getHours -->