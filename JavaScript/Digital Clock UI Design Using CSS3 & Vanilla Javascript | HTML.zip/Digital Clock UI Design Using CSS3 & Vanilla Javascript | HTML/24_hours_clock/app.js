function clock() {
    // set the each times and grab the element of the DOM
    var hours = document.getElementById('hours');
    var minutes = document.getElementById('minutes');
    var seconds = document.getElementById('seconds');

    var h = new Date().getHours(); // .getHOurs method to get the local time 
    var m = new Date().getMinutes();
    var s = new Date().getSeconds();

    // send into the DOM that using emthod is .innerHTML so text
    hours.innerHTML = h;
    minutes.innerHTML = m;
    seconds.innerHTML = s;
}

var interval = setInterval(clock, 1000);