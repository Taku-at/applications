const slidePage = document.querySelector(".slidepage"),
firstNextBtn = document.querySelector(".nextBtn"),
secondPrevBtn = document.querySelector(".prev-1"),
secondNextBtn = document.querySelector(".next-1"),
thirdPrevBtn = document.querySelector(".prev-2"),
thirdNextBtn = document.querySelector(".next-2"),
fourthPrevBtn = document.querySelector(".prev-3"),
submitBtn = document.querySelector(".submit"),
progressText = document.querySelectorAll(".step p"),
progressCheck = document.querySelectorAll(".step .check"),
bullet = document.querySelectorAll(".step .bullet");

let max = 4;
let current = 1;

// add event
firstNextBtn.addEventListener("click", function(event){
    slidePage.style.marginLeft = "-25%";
    bullet[current - 1].classList.add("active");
    progressText[current - 1].classList.add("active");
    progressCheck[current - 1].classList.add("active");
    current += 1;
});
secondNextBtn.addEventListener("click", function(event){
    slidePage.style.marginLeft = "-50%";
    bullet[current - 1].classList.add("active");
    progressText[current - 1].classList.add("active");
    progressCheck[current - 1].classList.add("active");
    current += 1;
});
thirdNextBtn.addEventListener("click", function(event){
    slidePage.style.marginLeft = "-75%";
    bullet[current - 1].classList.add("active");
    progressText[current - 1].classList.add("active");
    progressCheck[current - 1].classList.add("active");
    current += 1;
});
submitBtn.addEventListener("click", function(){
    bullet[current - 1].classList.add("active");
    progressText[current - 1].classList.add("active");
    progressCheck[current - 1].classList.add("active");
    current += 1;
    setTimeout(function() {
        alert("Your Form Successfully Signed up");
        location.reload();
    }, 800);
})
// remove
secondPrevBtn.addEventListener("click", function(event){
    slidePage.style.marginLeft = "0%";
    bullet[current - 2].classList.remove("active");
    progressText[current - 2].classList.remove("active");
    progressCheck[current - 2].classList.remove("active");
    current -= 1;
});
thirdPrevBtn.addEventListener("click", function(event){
    slidePage.style.marginLeft = "-25%";
    bullet[current - 2].classList.remove("active");
    progressText[current - 2].classList.remove("active");
    progressCheck[current - 2].classList.remove("active");
    current -= 1;
});
fourthPrevBtn.addEventListener("click", function(event){
    slidePage.style.marginLeft = "-50%";
    bullet[current - 2].classList.remove("active");
    progressText[current - 2].classList.remove("active");
    progressCheck[current - 2].classList.remove("active");
    current -= 1;
});