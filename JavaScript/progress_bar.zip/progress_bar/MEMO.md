## Link
[Youtube_part-1](https://www.youtube.com/watch?v=FKIafz8qgpk&t=238s)

[Youtube_part-2](https://www.youtube.com/watch?v=UldBI0fdMJw&t=0s)

## calc() function
[MDN](https://developer.mozilla.org/en-US/docs/Web/CSS/calc())

## scaleX() function
[W3S](https://www.w3schools.com/css/css3_2dtransforms.asp)

## must add the active of class 


## If the classList doesn't work then we check the correct class name that misspelling whether or not 