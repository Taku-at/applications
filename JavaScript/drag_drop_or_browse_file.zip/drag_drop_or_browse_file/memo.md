[@Youtube]
HTML and CSS
<!-- https://www.youtube.com/watch?v=LfCTEgK5XEg -->
JavaScript
<!-- https://www.youtube.com/watch?v=6-jxnQIKyKA&t=0s -->



place-items
<!-- https://developer.mozilla.org/en-US/docs/Web/CSS/place-items -->

background-clip is set the background underneath the image


[@Youtube_2]

alert(imgURL);