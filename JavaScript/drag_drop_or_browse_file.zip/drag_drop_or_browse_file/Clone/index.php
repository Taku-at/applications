<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drag and Drop</title>
    <link rel="stylesheet" href="style.css">
    <!-- font awesome my token -->
    <script src="https://kit.fontawesome.com/7c47e961fa.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="wrapper">
        <div class="preview-box">
            <div class="cancel-icon"><i class="fas fa-times"></i></div>
            <div class="img-preview">
            </div>
            <div class="content">
                 <div class="img-content"><i class="fas fa-cloud-upload-alt"></i></div>
                <!-- <div class="img-content"><i class="fas fa-image"></i></div> -->
                <div class="text">Paste the Image Below, <br/>to see a preview or download!</div>
            </div>
        </div>
        <form action="#" class="input-data">
            <input type="text" id="field" placeholder="Paste the image url to download...">
            <input type="submit" id="button" value="Download">
       </form>  
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function(){
            // if user focus out from the input
            $("#field").on("focusout", function(){
                // getting user entered img URL
                var imgURL = $("#field").val();
                if(imgURL != ""){ // if input field ins't blank
                    var regPattern = /\.(jpg?g|png|gif|bmp)$/i; // pattern to validating img extension
                    if(regPattern.test(imgURL)) { // if pattern matched to URL
                        var imgTag = '<img src="'+ imgURL +'" alt="">'; // creating a new img tag to show img
                        $(".img-preview").append(imgTag); // appending img tag with user entered img url
                        // adding new class which I've been created in css
                        $(".preview-box").addClass("imgActive");
                        $("#button").addClass("active");
                        $("#field").addClass("disabled");
                        $('.cancel-icon').on("click", function() {
                            // we'll remove all new added class on cancel icon click.
                            $(".preview-box").removeClass("imgActive");
                            $("#button").removeClass("active");
                            $("#field").removeClass("disabled");
                            $(".img-preview img").remove();
                            // that's all i JavaScript/jQuery
                        });
                    } else {
                        alert("invalid img URL - " + imgURL);
                        $("#field").val(); // if pattern not matched we'll leave the input field blank
                    }
                }
            });
        });

    </script>
</body>
</html>