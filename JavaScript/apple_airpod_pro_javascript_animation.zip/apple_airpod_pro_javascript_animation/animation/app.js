
// snatch the id of the DOM
const intro = document.querySelector('.intro');
// retrieve the attributes
const video = intro.querySelector('video');
const text = intro.querySelector('h1');
// END SECTION
const section = document.querySelector('section');
const end = section.querySelector('#fadeOutText');

// SCROLLMAJIC
const controller = new ScrollMagic.Controller();


// SCENE Animation
let scene = new ScrollMagic.Scene({
    duration: 9000, // animation time to be set what ever you want
    triggerElement: intro, // display where 
    triggerHook: 0 // where at the point 
})
    .addIndicators()
    .setPin(intro)
    .addTo(controller);  

// Text Animation
const textAnim = TweenMax.fromTo(text, 3, {opacity: 1}, {opacity: 0});

let scene2 = new ScrollMagic.Scene({
    duration: 3000,
    triggerElement: intro,
    triggerHook: 0
})
    .setTween(textAnim)
    .addTo(controller);

// Section Animation
let scene3 = new ScrollMagic.Scene({
    duration: 4500,
    triggerElement: section,
    triggerHook: 0
})
    .addIndicators()
    .setPin(section)
    .addTo(controller);

// End of the text Animation
const textAnim2 = TweenMax.fromTo(end, 3, {opacity: 1}, {opacity: 0});

let scene4 = new ScrollMagic.Scene({
    duration: 3000,
    triggerElement: section,
    triggerHook: 0
})
    .setTween(textAnim2)
    .addTo(controller);


// Video animation that is next section of animation accelatation amount
let accelAmount = 0.1;
let scrollpos = 0;
let delay = 0;

scene.on("update", e => {
    // 9000 of duration divide 1000
    scrollpos = e.scrollPos / 1000; // scrollPos.nethod on the e event
});

setInterval(() => {
    delay += (scrollpos - delay) * accelAmount;
    console.log(scrollpos, delay);

    video.currentTime = delay;
}, 33.3);

/*
33 is framerate that is 1000 divided by 30 framerate
if 24 per second video 41.6 framerates
*/