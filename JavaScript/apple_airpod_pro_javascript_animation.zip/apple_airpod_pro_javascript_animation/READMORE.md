[pexel]
<!-- https://www.pexels.com/search/videos/dynamic%20video/ -->

[Youtube]
<!-- https://www.youtube.com/watch?v=wLUJ9VNzZXo -->


[scrollMajic]
<!-- https://cdnjs.com/libraries/ScrollMagic -->



[JavaScript]
new constructor
<!-- https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/new -->

+=
<!-- https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Addition_assignment -->

ease which means to be more natural
<!-- https://developers.google.com/web/fundamentals/design-and-ux/animations/the-basics-of-easing -->