// Selectors
const todoInput = document.querySelector(".todo-input");
const todoButton = document.querySelector(".todo-button");
const todoList = document.querySelector(".todo-list");
const filterOption = document.querySelector(".filter-todo");


// Event Listners
document.addEventListener("DOMContentLoaded", getTodos); /* IMPORTANT when refresh the browser, leaving the content */
document.addEventListener("DOMContentLoaded", getMyTodos); /* IMPORTANT when refresh the browser, leaving the content */
todoButton.addEventListener("click", addTodo);
todoList.addEventListener("click", deleteCheck);
filterOption.addEventListener("click", filterTodo);/* tirigger event and function */

// Functions
function addTodo(event){
    // Prevent form from submitting
    event.preventDefault();
    // Todo DIV
    const todoDiv = document.createElement("div");
    todoDiv.classList.add("todo");
    // Create Li
    const newTodo = document.createElement("li");
    newTodo.innerText = todoInput.value; /* to insert the value of text when typing. */
    newTodo.classList.add("todo-item"); /* add the class to the li */
    todoDiv.appendChild(newTodo); // add the div at the end
    // Add Todo Tpo Localstorage
    saveLocalTodos(todoInput.value);
    // Generate the Check Mark Button
    const completedButton = document.createElement("button");
    completedButton.innerHTML = '<i class="fas fa-check"></i>'; // gonna render out teh text
    completedButton.classList.add("complete-btn");
    todoDiv.appendChild(completedButton);
    // Generate the trash Button
    const trashButton = document.createElement("button");
    trashButton.innerHTML = '<i class="fas fa-trash"></i>'; // gonna render out teh text
    trashButton.classList.add("trash-btn");
    todoDiv.appendChild(trashButton);
    // Append To Lists
    todoList.append(todoDiv);
    // Clear Todo Input value
    todoInput.value = ""; /* to reflesh the input field */
}

function deleteCheck(e) {
    const item = e.target;
    // Delete Todo
    if(item.classList[0] === "trash-btn") {
        const todo = item.parentElement;
        //Animation
        todo.classList.add("fall");
        removeLocalTodos(todo);
        todo.addEventListener('transitionend', function() {
            todo.remove(); /* remove the list when animation is ended */
        });
    }

    // Check Mark
    if(item.classList[0] === "complete-btn") {
        const todo = item.parentElement;
        todo.classList.toggle("completed");
    }
}

function  filterTodo(e) {
    const todos = todoList.childNodes; /* get the list of Node */
    todos.forEach(function(todo) {
        switch(e.target.value) {
            case "all":
                todo.style.display = "flex";
                break;
            case "completed":
                if(todo.classList.contains("completed")){
                    todo.style.display = "flex";
                } else {
                    todo.style.display = "none";
                }
                break;
            case "uncompleted":
                if(!todo.classList.contains("completed")){
                    todo.style.display = "flex";
                } else {
                    todo.style.display = "none";
                }
                break;
        }
    });
}


/* --==================
Localstorage section 
======================-- */
function saveLocalTodos(todo) {
    // Check---Hey, do you already have thing in there?
    let todos;
    if(localStorage.getItem('todos') === null) {
        todos = []; // create an array if we don't have it.
    } else {
        todos = JSON.parse(localStorage.getItem("todos")); /* to pass nto an array */
    }
    
    todos.push(todo); /* push add the array */
    localStorage.setItem("todos", JSON.stringify(todos)); // JSON can send the object to the server as string so display them
}

// 
function getTodos() {
    // Check---Hey, do you already have thing in there?
    let todos;
    if(localStorage.getItem('todos') === null) {
        todos = []; // create an array if we don't have it.
    } else {
        todos = JSON.parse(localStorage.getItem("todos")); /* to pass nto an array */
    }
    todos.forEach(function(todo) {
    // Todo DIV
    const todoDiv = document.createElement("div");
    todoDiv.classList.add("todo");
    // Create Li
    const newTodo = document.createElement("li");
    newTodo.innerText = todo; /* to insert the value of text when typing. */
    newTodo.classList.add("todo-item"); /* add the class to the li */
    todoDiv.appendChild(newTodo); // add the div at the end

    // Generate the Check Mark Button
    const completedButton = document.createElement("button");
    completedButton.innerHTML = '<i class="fas fa-check"></i>'; // gonna render out teh text
    completedButton.classList.add("complete-btn");
    todoDiv.appendChild(completedButton);
    // Generate the trash Button
    const trashButton = document.createElement("button");
    trashButton.innerHTML = '<i class="fas fa-trash"></i>'; // gonna render out teh text
    trashButton.classList.add("trash-btn");
    todoDiv.appendChild(trashButton);
    // Append To Lists
    todoList.append(todoDiv);
    });
}

const removeLocalTodos = todo => {
    // Check---Hey, do you already have thing in there?
    let todos;
    if(localStorage.getItem('todos') === null) {
        todos = []; // create an array if we don't have it.
    } else {
        todos = JSON.parse(localStorage.getItem("todos")); /* to pass nto an array */
    }
    const todoIndex = todo.children[0].innerText; // display the trash index
    todos.splice(todos.indexOf(todoIndex), 1); // what is the index is spliced and show how many
    localStorage.setItem("todos", JSON.stringify(todos));
};

/* --============
My basic task
--=============== */
/* Add the task inside the array */

function getMyTodos() {
    // Check---Hey, do you already have thing in there?
    let todos;
    if(localStorage.getItem('todos')) {
        todos = [   
        "JavaScript", 
        "WordPress", 
        "CodeCademy", 
        "PHP",
        "Bootstrap",
        "Figma",
        "Tutorial",
        "Application" 
        ]; // create an array if we don't have it.
    } else {
        todos = JSON.parse(localStorage.getItem("todos")); /* to pass nto an array */
    }
    todos.forEach(function(todo) {
    // Todo DIV
    const todoDiv = document.createElement("div");
    todoDiv.classList.add("todo");
    // Create Li
    const newTodo = document.createElement("li");
    newTodo.innerText = todo; /* to insert the value of text when typing. */
    newTodo.classList.add("todo-item"); /* add the class to the li */
    todoDiv.appendChild(newTodo); // add the div at the end

    // Generate the Check Mark Button
    const completedButton = document.createElement("button");
    completedButton.innerHTML = '<i class="fas fa-check"></i>'; // gonna render out teh text
    completedButton.classList.add("complete-btn");
    todoDiv.appendChild(completedButton);
    // Generate the trash Button
    const trashButton = document.createElement("button");
    trashButton.innerHTML = '<i class="fas fa-trash"></i>'; // gonna render out teh text
    trashButton.classList.add("trash-btn");
    todoDiv.appendChild(trashButton);
    // Append To Lists
    todoList.append(todoDiv);
    });
}


// localStorage.clear();