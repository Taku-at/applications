add filter that check the what we have completed
to save the local storage

Done by 4 hours