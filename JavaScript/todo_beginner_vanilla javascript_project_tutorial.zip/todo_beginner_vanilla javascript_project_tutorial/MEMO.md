[@Youtube]
<!-- https://www.youtube.com/watch?v=Ttf3CEsEwMQ -->


background-attachment
<!-- https://developer.mozilla.org/en-US/docs/Web/CSS/background-attachment -->

text-decoration-line
<!-- https://developer.mozilla.org/en-US/docs/Web/CSS/text-decoration-line -->

[DOM]
childNode
return the list of Nodes
<!-- https://www.w3schools.com/jsref/prop_node_childnodes.asp -->

[JSON]
JSON.stringify()
<!-- https://www.w3schools.com/js/js_json_stringify.asp -->

::after can create something object

How to check the event
<!-- 
function deleteCheck(e) {
    console.log(e.target);
} -->

[@error]
In this case, item is not declared
<!-- app.js:41 Uncaught ReferenceError: item is not defined
    at HTMLUListElement.deleteCheck 
     -->

[clear]
localStorage.clear()