## Thanks a lot that you coming here


## Links

[Youtube](https://www.youtube.com/watch?v=QTHRWGn_sJw)

[Bensound](https://www.bensound.com/royalty-free-music/jazz)

[CDNjs](https://cdnjs.com/)


## Memo

id which is grabbed bt JavaScript

audio tag is api 

## JavaScript in order

-- create event then create the function

 
## function updateProgress(e) { 
    console.log(e.srcElement.duration)
    console.log(e.srcElement.currentTime)
}

## need to know 
- use mp3 and jpg
-- song name is correctly to correspond