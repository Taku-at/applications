// variables grab the id
const search = document.getElementById('search');
const matchList = document.getElementById('match-list');

// search states.json and filter it
// fettch is using the async
const searchStates = async searchText => {
    // usually fetch api with the URL as file location
    const res = await fetch('../json/state.json');
    // states is json file name
    const states = await res.json();

    // Get matches to current text input
    /* filter method which is a high order array and returns and array  based on a condition or multiple conditions */
    let matches = states.filter(state => {
        // regular expressions to match the word
        // ^ which means to start with any 
        // gi is global and flags so case-in senseitive
        const regex = new RegExp(`^${searchText}`, `gi`);
        return state.name.match(regex) || state.abbr.match(regex);
    });

    // clear the text using by the empty array and quotes
    if(searchText.length === 0) {
        // the empty array which means to clear everything out
        matches = [];
        matchList.innerHTML = '';

    }

    // output in the HTML
    outputHtml(matches);
};

// Show results in HTML
const outputHtml = matches => {
    if(matches.length > 0) {
        // the map through the array to be returned
        const html = matches.map(
            match => `
            <div class="card card-body mb-1">
                <h4>${match.name} (${match.abbr}) <span class="text-primary">${match.capital}</span></h4>
                <samll>Lat: ${match.lat} / Long: ${match.long}</small>
            </div>
        `
        )
        .join('');

        // to display the results
        matchList.innerHTML = html;
        console.log(html)
    }

}


// fire the event on input 
// serch the value of state to be passed
search.addEventListener('input', () => searchStates(search.value));