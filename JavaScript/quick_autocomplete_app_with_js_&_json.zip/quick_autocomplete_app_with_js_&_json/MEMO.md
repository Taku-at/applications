[Youtube]
<!-- https://www.youtube.com/watch?v=1iysNUrI3lw -->

[GitHub]
<!-- https://gist.github.com/bradtraversy/20dee7787486d10db3bd1f55fae5fdf4 -->

[Bootswatch]
<!-- https://bootswatch.com/ -->