## Links
[Youtube](https://www.youtube.com/watch?v=MPK_7uMPQ7Q)

[latlong](https://www.gps-coordinates.net/)

## plugin
[gmaps.js](https://github.com/hpneo/gmaps)